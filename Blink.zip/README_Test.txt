File names of images in the test folder are <ID>.jpg

You'll need to modify the data reader to load this data and process it.

Submissions should be in the form:

ID <1/0>

Where 1 is for closed and 0 is for opened.