
import AdultSupport
import Evaluations

### UPDATE this path for your environment
kDataPath = "..\\..\\..\\Datasets\\Adult\\adult.data"

(xRaw, yRaw) = AdultSupport.LoadRawData(kDataPath)

(xTrainRaw, yTrainRaw, xValidateRaw, yValidateRaw, xTestRaw, yTestRaw) = AdultSupport.TrainValidateTestSplit(xRaw, yRaw)

print("Train is %d samples, %f percent >50K." % (len(yTrainRaw), sum(yTrainRaw)/len(yTrainRaw)))
print("Validate is %d samples, %f percent >50K." % (len(yValidateRaw), sum(yValidateRaw)/len(yValidateRaw)))
print("Test is %d samples %f percent >50K." % (len(yTestRaw), sum(yTestRaw)/len(yTestRaw)))

(xTrain, xValidate, xTest) = AdultSupport.Featurize(xTrainRaw, xValidateRaw, xTestRaw)
yTrain = yTrainRaw
yValidate = yValidateRaw
yTest = yTestRaw

#AdultSupport.InspectFeatures([xTrain[0]], [xTrainRaw[0]])

print("Num features is: %d" % len(xTrain[0]))

############################
import MostCommonModel

model = MostCommonModel.MostCommonModel()
model.fit(xTrain, yTrain)
yValidatePredicted = model.predict(xValidate)

print("### 'Most Common' model")

Evaluations.ExecuteAll(yValidate, yValidatePredicted)

############################
#import DecisionTreeModel
#model = DecisionTreeModel.DecisionTree()

#print("Decision Tree model")
#for minToSplit in [10000]:
#    model.fit(xTrain, yTrain,  minToSplit=minToSplit)
#    yValidatePredicted = model.predict(xValidate)

#    model.visualize()
    
#    print("minToSplit:", minToSplit)
#    Evaluations.ExecuteAll(yValidate, yValidatePredicted)

