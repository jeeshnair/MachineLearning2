import collections
import os

def LoadRawData(path):
    print("Loading data from: %s" % os.path.abspath(path))
    f = open(path, 'r')
    
    lines = f.readlines()

    kNumberExamplesExpected = 5474

    if(len(lines) != kNumberExamplesExpected):
        message = "Attempting to load %s:\n" % (path)
        message += "   Expected %d lines, got %d.\n" % (kNumberExamplesExpected, len(lines))
        message += "    Check the path to training data and try again."
        raise UserWarning(message)

    x = []
    y = []

    for l in lines:
        if(l.startswith('ham')):
            y.append(0)
            x.append(l[4:])
        elif(l.startswith('spam')):
            y.append(1)
            x.append(l[5:])
        else:
            message = "Attempting to process %s\n" % (l)
            message += "   Did not match expected format."
            message += "    Check the path to training data and try again."
            raise UserWarning(message)

    return (x, y)

def TrainValidateTestSplit(x, y, percentValidate = .1, percentTest = .1):
    if(len(x) != len(y)):
        raise UserWarning("Attempting to split into training and testing set.\n\tArrays do not have the same size. Check your work and try again.")

    numTest = round(len(x) * percentTest)
    numValidate = round(len(x) * percentValidate)

    if(numValidate == 0 or numValidate > len(y)):
        raise UserWarning("Attempting to split into training, validation and testing set.\n\tSome problem with the percentValidate or data set size. Check your work and try again.")

    if(numTest == 0 or numTest > len(y)):
        raise UserWarning("Attempting to split into training, validation and testing set.\n\tSome problem with the percentTest or data set size. Check your work and try again.")

    xTest = x[:numTest]
    xValidate = x[numTest:numTest + numValidate]
    xTrain = x[numTest + numValidate:]
    yTest = y[:numTest]
    yValidate = y[numTest: numTest+numValidate]
    yTrain = y[numTest+numValidate:]

    return (xTrain, yTrain, xValidate, yValidate, xTest, yTest)


def DoFeaturize(xRaw, words):
    dataSet = []

    for x in xRaw:
        features = []

        # Have a feature for longer texts
        if(len(x)>40):
            features.append(1)
        else:
            features.append(0)

        # Have a feature for texts with numbers in them
        if(any(i.isdigit() for i in x)):
            features.append(1)
        else:
            features.append(0)

        # Have features for a few words
        for word in words:
            if word in x:
                features.append(1)
            else:
                features.append(0)

        dataSet.append(features)

    return dataSet

def Featurize(xTrainRaw, xValidateRaw, xTestRaw):
    
    # might do a pass over the training set to figure out what features to use
    words = ['call', 'to', 'your']

    # featurize the training data.
    xTrain = DoFeaturize(xTrainRaw, words)
    
    # now featurize validate and test using any features discovered on the training set. Don't use the validate or test set to influence which features (e.g. words) to use.
    xValidate = DoFeaturize(xValidateRaw, words)
    xTest = DoFeaturize(xTestRaw, words)

    return (xTrain, xValidate, xTest)

def InspectFeatures(xRaw, x):
    for i in range(len(xRaw)):
        print(x[i], xRaw[i])

