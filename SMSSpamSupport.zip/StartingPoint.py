
import SMSSpamSupport
import EvaluationsStub

### UPDATE this path for your environment
kDataPath = "..\\..\\..\\Datasets\\SMS Spam\\SMSSpamCollection"

(xRaw, yRaw) = SMSSpamSupport.LoadRawData(kDataPath)

(xTrainRaw, yTrainRaw, xValidateRaw, yValidateRaw, xTestRaw, yTestRaw) = SMSSpamSupport.TrainValidateTestSplit(xRaw, yRaw)

print("Train is %d samples, %f percent spam." % (len(yTrainRaw), sum(yTrainRaw)/len(yTrainRaw)))
print("Validate is %d samples, %f percent spam." % (len(yValidateRaw), sum(yValidateRaw)/len(yValidateRaw)))
print("Test is %d samples %f percent spam." % (len(yTestRaw), sum(yTestRaw)/len(yTestRaw)))

(xTrain, xValidate, xTest) = SMSSpamSupport.Featurize(xTrainRaw, xValidateRaw, xTestRaw)
yTrain = yTrainRaw
yValidate = yValidateRaw
yTest = yTestRaw

############################
import MostCommonModel

model = MostCommonModel.MostCommonModel()
model.fit(xTrain, yTrain)
yValidatePredicted = model.predict(xValidate)

print("### 'Most Common' model")

EvaluationsStub.ExecuteAll(yValidate, yValidatePredicted)

############################
import SpamHeuristicModel
model = SpamHeuristicModel.SpamHeuristicModel()
model.fit(xTrain, yTrain)
yValidatePredicted = model.predict(xValidate)

print("### Heuristic model")

EvaluationsStub.ExecuteAll(yValidate, yValidatePredicted)

############################
# import LogisticRegressionModel
# model = LogisticRegressionModel.LogisticRegressionModel()

# print("Logistic regression model")
# for i in [50000]:
#     model.fit(xTrain, yTrain, iterations=i, step=0.01)
#     yValidatePredicted = model.predict(xValidate)
    
#     print("%d, %f, %f, %f" % (i, model.weights[1], model.loss(xValidate, yValidate), EvaluationsStub.Accuracy(yValidate, yValidatePredicted)))

# EvaluationsStub.ExecuteAll(yValidate, yValidatePredicted)

# Don't use the test data yet...save that for after we do some more serious feature engineering.
