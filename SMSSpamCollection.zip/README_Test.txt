Test data format is:

ID <space> <SMS Message Text>

You'll need to modify the data reader to load this data and process it.

Submissions should be in the form:

ID <1/0>

Where 1 is for spam and 0 is for not spam.