Test data format is:

ID, <Columns in training data>

But the target column was replaced by the string 'ANSWER' (NOTE THERE IS ALSO A HEADER ROW)

You'll need to modify the data reader to load this data and process it.

Submissions should be in the form:

ID <1/0>

Where 1 is for >50k and 0 is for <=50k